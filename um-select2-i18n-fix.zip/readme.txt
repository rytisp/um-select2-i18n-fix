=== UM Select2 i18n Hard ===
Contributors: you
Requires at least: 5.8
Tested up to: 6.6
Stable tag: 1.1.1
License: GPLv2 or later

Fixes "Cannot read properties of undefined (reading 'define')" from Select2 i18n files by loading Select2 full early, blocking i18n bundles, and guarding AMD.
